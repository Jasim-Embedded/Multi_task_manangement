package model;

import java.sql.Date;

public class Task {
    public int tenantId;
    public int projectId;
    public int assigneeId;
    public String title;
    public String status;
    public Date dueDate;

    public Task(int tenantId, int projectId, int assigneeId,
                String title, String status, Date dueDate) {
        this.tenantId = tenantId;
        this.projectId = projectId;
        this.assigneeId = assigneeId;
        this.title = title;
        this.status = status;
        this.dueDate = dueDate;
    }
}
