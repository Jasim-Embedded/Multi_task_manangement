package model;

public class AuditLog {
    public int userId;
    public String action;

    public AuditLog(int userId, String action) {
        this.userId = userId;
        this.action = action;
    }
}
