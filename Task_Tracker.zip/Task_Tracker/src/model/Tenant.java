package model;

public class Tenant {
    private int id;
    private String name;

    public Tenant(String name) {
        this.name = name;
    }

    public int getId() { return id; }
    public String getName() { return name; }
}
