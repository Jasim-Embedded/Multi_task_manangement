package service;

import config.DBConnection;
import model.User;
import java.sql.*;

public class AuthService {

    public static User loggedInUser;

    public boolean login(String email, String password) {
        String sql = "SELECT * FROM users WHERE email=? AND password=?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, email);
            ps.setString(2, password);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                loggedInUser = new User(
                        rs.getInt("id"),
                        rs.getInt("tenant_id"),
                        rs.getString("email"),
                        rs.getString("role")
                );
                return true;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
}
