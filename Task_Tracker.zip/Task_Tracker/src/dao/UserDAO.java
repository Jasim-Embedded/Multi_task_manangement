package dao;

import config.DBConnection;
import model.User;
import java.sql.*;

public class UserDAO {

    public void createUser(User u) {
        String sql = "INSERT INTO users(tenant_id,email,password,role) VALUES(?,?,?,?)";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, u.tenantId);
            ps.setString(2, u.email);
            ps.setString(3, u.password);
            ps.setString(4, u.role);
            ps.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
