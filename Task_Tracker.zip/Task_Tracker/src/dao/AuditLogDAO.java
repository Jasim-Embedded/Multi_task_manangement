package dao;

import config.DBConnection;
import model.AuditLog;
import java.sql.*;

public class AuditLogDAO {

    public void log(AuditLog log) {
        String sql = "INSERT INTO audit_logs(user_id,action) VALUES(?,?)";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, log.userId);
            ps.setString(2, log.action);
            ps.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
