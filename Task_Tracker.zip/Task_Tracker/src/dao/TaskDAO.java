package dao;

import config.DBConnection;
import model.Task;
import java.sql.*;

public class TaskDAO {

    public void createTask(Task t) {
        String sql = "INSERT INTO tasks VALUES(NULL,?,?,?,?,?,?)";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, t.tenantId);
            ps.setInt(2, t.projectId);
            ps.setInt(3, t.assigneeId);
            ps.setString(4, t.title);
            ps.setString(5, t.status);
            ps.setDate(6, t.dueDate);
            ps.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void viewTasksForUser(int userId) {
        String sql = "SELECT * FROM tasks WHERE assignee_id=?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                System.out.println(
                    rs.getInt("id") + " | " +
                    rs.getString("title") + " | " +
                    rs.getString("status")
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void updateStatus(int taskId, String status) {
        String sql = "UPDATE tasks SET status=? WHERE id=?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, status);
            ps.setInt(2, taskId);
            ps.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
