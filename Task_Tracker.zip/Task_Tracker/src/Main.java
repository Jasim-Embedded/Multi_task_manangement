import dao.*;
import model.*;
import service.AuthService;
import java.sql.Date;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        TenantDAO tenantDAO = new TenantDAO();
        UserDAO userDAO = new UserDAO();
        TaskDAO taskDAO = new TaskDAO();
        AuditLogDAO auditDAO = new AuditLogDAO();
        AuthService auth = new AuthService();

        int tenantId = tenantDAO.createTenant("GCC Corp");

        userDAO.createUser(new User(tenantId,"super@sys.com","123","SUPER ADMIN"));
        userDAO.createUser(new User(tenantId,"admin@gcc.com","123","TENANT ADMIN"));
        userDAO.createUser(new User(tenantId,"lead@gcc.com","123","TEAM LEAD"));
        userDAO.createUser(new User(tenantId,"user@gcc.com","123","REGULAR USER"));

        System.out.println("Login Email:");
        String email = sc.next();
        System.out.println("Password:");
        String pass = sc.next();

        if (!auth.login(email, pass)) {
            System.out.println("Invalid Login");
            return;
        }

        User u = AuthService.loggedInUser;
        auditDAO.log(new AuditLog(u.id, "Logged in"));

        if (u.role.equals("TEAM LEAD")) {
            System.out.println("1. Create Task");
            int ch = sc.nextInt();
            sc.nextLine();
            if (ch == 1) {
                System.out.print("Task Title: ");
                String title = sc.nextLine();
                Task t = new Task(u.tenantId,1,4,title,"OPEN",Date.valueOf("2025-01-20"));
                taskDAO.createTask(t);
                auditDAO.log(new AuditLog(u.id,"Created Task"));
            }
        }

        System.out.println("Your Tasks:");
        taskDAO.viewTasksForUser(u.id);

        System.out.print("Update Task ID: ");
        int id = sc.nextInt();
        sc.nextLine();
        System.out.print("New Status: ");
        String status = sc.nextLine();
        taskDAO.updateStatus(id,status);
        auditDAO.log(new AuditLog(u.id,"Updated Task "+id));
    }
}